﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace allaboutspace_domain.models.launches
{
    public class Launch_service_provider
    {
        public int id { get; set; }
        public string name { get; set; }
        public bool featured { get; set; }
        public string? type { get; set; }
        public string country_code { get; set; }
        public string abbrev { get; set; }
        public string? description { get; set; }

        public string? logo_url { get; set; }
        public string? image_url { get; set; }
    }
}
