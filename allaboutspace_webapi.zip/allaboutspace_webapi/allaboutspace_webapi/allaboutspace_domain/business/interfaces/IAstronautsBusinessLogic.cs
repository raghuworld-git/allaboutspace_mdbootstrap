﻿using allaboutspace_domain.models.astronauts;
using allaboutspace_domain.models.common;


namespace allaboutspace_domain.business.interfaces
{
    public interface IAstronautsBusinessLogic
    {
        public Task<GenericPaginationResponse<AstronautSimple>> GetAllAstronautsByAsync(int limit, int offset);
        public Task<AstronautDetailed> GetAstronautByIdAsync(int id);
    }
}
