﻿using allaboutspace_domain.models.common;
using allaboutspace_domain.models.launches;


namespace allaboutspace_domain.respository.interfaces
{
    public interface ILaunchesRepository
    {
        public Task<GenericPaginationResponse<LaunchList>> GetAllUpcomingLaunchesByAsync(int limit, int offset);
        public Task<GenericPaginationResponse<LaunchList>> GetAllPastLaunchesByAsync(int limit, int offset);
    }
}
