﻿using allaboutspace_domain.business.interfaces;
using allaboutspace_domain.models.astronauts;
using allaboutspace_domain.models.common;
using allaboutspace_domain.models.launches;
using Microsoft.AspNetCore.Mvc;

namespace allaboutspace_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LaunchesController : ControllerBase
    {
        private readonly ILaunchesBusinessLogic _launchesBL;

        public LaunchesController(ILaunchesBusinessLogic launchesBL)
        {
            _launchesBL = launchesBL;
        }
        [HttpGet]
        [Route("[action]")]
        public async Task<ActionResult<GenericPaginationResponse<LaunchList>>> GetUpcomingLaunches(int limit = 8, int offset = 10)
        {
            var result = await _launchesBL.GetAllUpcomingLaunchesByAsync(limit, offset);
            if (result is not null)
            {
                if (result.count >= 1)
                {
                    return Ok(result);
                }
            }

            return NotFound();

        }

        [HttpGet]
        [Route("[action]")]
        public async Task<ActionResult<GenericPaginationResponse<LaunchList>>> GetPastLaunches(int limit = 8, int offset = 10)
        {
            var result = await _launchesBL.GetAllPastLaunchesByAsync(limit, offset);
            if (result is not null)
            {
                if (result.count >= 1)
                {
                    return Ok(result);
                }
            }

            return NotFound();

        }

        [HttpGet]
        [Route("[action]/{id}")]
        public async Task<ActionResult<LaunchDetail>> GetLaunchDetails(string id)
        {
            var result = await _launchesBL.GetLaunchDetails(id);
            if (result is not null)
            {
                return Ok(result);
            }

            return NotFound();

        }
    }
}
