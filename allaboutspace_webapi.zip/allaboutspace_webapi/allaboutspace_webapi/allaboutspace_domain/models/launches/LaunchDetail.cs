﻿
using allaboutspace_domain.models.common;

namespace allaboutspace_domain.models.launches
{
    public class LaunchDetail
    {
        public string id { get; set; }
        public string name { get; set; }
        public Status status { get; set; }
        public string? net { get; set; }
        public DateTime? net_converted
        {
            get
            {
                if (net != null)
                {
                    try
                    {
                       return DateTime.Parse(net);
                    }
                    catch
                    {
                        return null;
                    }
                }
                return null;
            }
        }
        public string? weather_concerns { get; set; }
        public string? holdreason { get; set; }
        public string? failreason { get; set; }
        public Launch_service_provider? launch_service_provider { get; set; }

        public Rocket? rocket { get; set; }

        public Mission? mission { get; set; }

        public Pad? pad { get; set; }

        public string? image { get; set; }


    }
}
