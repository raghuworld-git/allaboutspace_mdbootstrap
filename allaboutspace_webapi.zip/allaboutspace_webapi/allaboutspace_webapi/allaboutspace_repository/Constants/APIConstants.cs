﻿namespace allaboutspace_repository.Constants
{
    public static class APIConstants
    {
        public const string AstronautEndpoint = "astronaut";
        public const string LaunchEndpoint = "launch";
    }
}
