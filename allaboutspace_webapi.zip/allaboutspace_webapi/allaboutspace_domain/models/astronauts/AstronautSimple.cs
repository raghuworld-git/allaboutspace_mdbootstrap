﻿using allaboutspace_domain.models.agency;
using allaboutspace_domain.models.common;
using System.Text;
using System.Text.RegularExpressions;
using Type = allaboutspace_domain.models.common.Type;

namespace allaboutspace_domain.models.astronauts
{
    public class AstronautSimple
    {
        public int id { get; set; }
        public string name { get; set; }
        public Status status { get; set; }
        public Type type { get; set; }
        public string time_in_space { get; set; }
        public string eva_time { get; set; }
        public string time_in_space_formatted
        {
            get
            {

                var formattedString = new StringBuilder();
                if (time_in_space is not null)
                {
                    var match = Regex.Match(time_in_space, DomainConstants.RegexPatternForTIS);
                    if (match.Success)
                    {

                        for (int i = 0; i < match.Groups.Count; i++)
                        {
                            if (i != 0 && i != 2)
                            {
                                if (match.Groups[i].Success)
                                {
                                    formattedString.Append($"{match.Groups[i].Value},");
                                }
                            }
                        }

                    }
                }
                else
                {
                    formattedString.Append("0D");
                }

                return formattedString.ToString().TrimEnd(',');
            }
        }
        public string eva_time_formatted
        {
            get
            {
                var formattedString = new StringBuilder();
                if (eva_time is not null)
                {
                    var match = Regex.Match(eva_time, DomainConstants.RegexPatternForEVA);
                    if (match.Success)
                    {

                        for (int i = 0; i < match.Groups.Count; i++)
                        {
                            if (i != 0 && i != 2)
                            {
                                if (match.Groups[i].Success)
                                {
                                    formattedString.Append($"{match.Groups[i].Value},");
                                }
                            }
                        }
                    }
                }
                else
                {
                    formattedString.Append("0D");
                }
                return formattedString.ToString().TrimEnd(',');

            }
        }
        public bool in_space { get; set; }
        public string nationality { get; set; }
        public string? profile_image { get; set; }
        public string? profile_image_thumbnail { get; set; }

    }
}
