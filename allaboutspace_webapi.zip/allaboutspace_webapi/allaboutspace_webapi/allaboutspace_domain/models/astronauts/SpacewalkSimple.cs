﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace allaboutspace_domain.models.astronauts
{
    public class SpacewalkSimple
    {
        public int id { get; set; }
        public string name { get; set; }
        public string? start { get; set; }
        public string? end { get; set; }
        public string duration { get; set; }
        public string? location { get; set; }      
    }
}
