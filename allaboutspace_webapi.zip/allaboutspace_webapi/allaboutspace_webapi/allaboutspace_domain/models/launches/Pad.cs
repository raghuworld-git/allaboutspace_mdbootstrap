﻿

namespace allaboutspace_domain.models.launches
{
    public class Pad
    {
        public int id { get; set; }
        public string name { get; set; }
        public string? map_url { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public Location location { get; set; }
        public string country_code { get; set; }
        public string map_image { get; set;}

    }
}
