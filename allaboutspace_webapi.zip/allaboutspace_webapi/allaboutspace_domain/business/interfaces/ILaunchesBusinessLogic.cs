﻿using allaboutspace_domain.models.common;
using allaboutspace_domain.models.launches;


namespace allaboutspace_domain.business.interfaces
{
    public interface ILaunchesBusinessLogic
    {
        public Task<GenericPaginationResponse<LaunchList>> GetAllLaunchesByAsync(int limit, int offset);
    }
}
