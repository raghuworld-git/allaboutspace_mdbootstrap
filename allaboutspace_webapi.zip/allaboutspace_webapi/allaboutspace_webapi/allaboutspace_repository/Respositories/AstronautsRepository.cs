﻿using allaboutspace_domain.models.astronauts;
using allaboutspace_domain.models.common;
using allaboutspace_domain.respository.interfaces;
using allaboutspace_repository.Constants;
using Microsoft.Extensions.Configuration;
using Flurl;
using Flurl.Http;


namespace allaboutspace_repository.Respositories
{
    public class AstronautsRepository : IAstronautsRepository
    {
        private readonly IConfiguration _config;
        private string url = string.Empty;
        public AstronautsRepository(IConfiguration configuration)
        {
            _config = configuration;
            url = $"{_config[EnvironmentConstants.TSD_BASEURL]}/{APIConstants.AstronautEndpoint}/";
        }
        public async Task<GenericPaginationResponse<AstronautSimple>> GetAllAstronautsByAsync(int limit, int offset)
        {
            var queryParams = new
            {
                mode = "list",
                limit = limit.ToString(),
                offset = offset.ToString(),
                order = "name",
                ordering = "name"
            };
            return await url.SetQueryParams(queryParams).GetJsonAsync<GenericPaginationResponse<AstronautSimple>>();
        }

        public async Task<AstronautDetailed> GetAstronautByIdAsync(int id)
        {
            return await url.AppendPathSegment(id.ToString()).GetJsonAsync<AstronautDetailed>();
        }
    }
}
