﻿using allaboutspace_domain.models.common;


namespace allaboutspace_domain.models.launches
{
    public class LaunchList
    {
        public string id { get; set; }
        public string slug { get; set; }
        public string name { get; set; }
        public Status status { get; set; }
        public string? net { get; set; }
        public string lsp_name { get; set; }
        public string location { get; set; }
        public string orbit { get; set; }
        public string? image { get; set; }
    }
}
