﻿namespace allaboutspace_domain.models.common
{
    public class GenericPaginationResponse<T>
    {
        public int count { get; set; }
        public IEnumerable<T> results { get; set; }
    }
}
