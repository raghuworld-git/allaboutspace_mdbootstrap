﻿using allaboutspace_domain.models.common;
using allaboutspace_domain.models.launches;


namespace allaboutspace_domain.respository.interfaces
{
    public interface ILaunchesRepository
    {
        public Task<GenericPaginationResponse<LaunchList>> GetAllLaunchesByAsync(int limit, int offset);        
    }
}
