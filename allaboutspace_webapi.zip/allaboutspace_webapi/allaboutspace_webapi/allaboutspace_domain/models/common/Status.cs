﻿
namespace allaboutspace_domain.models.common
{
    public class Status
    {
        public int id { get; set; }
        public string name { get; set; }
        public string abbrev { get; set; }

        public string description { get; set; }
    }
}
