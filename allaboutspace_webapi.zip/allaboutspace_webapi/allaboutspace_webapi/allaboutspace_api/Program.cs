using allaboutspace_businesslogic.businesslogic;
using allaboutspace_domain.business.interfaces;
using allaboutspace_domain.respository.interfaces;
using allaboutspace_repository.Respositories;

namespace allaboutspace_api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string allowSpecificOriginsVariable = "_myAllowSpecificOrigins";

            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            ConfigureServices(builder.Services, allowSpecificOriginsVariable);


            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseCors(allowSpecificOriginsVariable);
            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }

        private static void ConfigureServices(IServiceCollection services, string corsVariable)
        {          

            services.AddCors(options =>
            {
                options.AddPolicy(name: corsVariable,
                                  policy =>
                                  {
                                      policy.WithOrigins("https://localhost:4200",
                                                          "http://localhost:4200");
                                  });
            });
            services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen();

            #region Custom DI

            services.AddTransient<IAstronautsRepository, AstronautsRepository>();
            services.AddTransient<IAstronautsBusinessLogic, AstronautsBusinessLogic>();
            services.AddTransient<ILaunchesBusinessLogic, LaunchesBusinessLogic>();
            services.AddTransient<ILaunchesRepository, LaunchesRepository>();

            #endregion
        }
    }
}