﻿using allaboutspace_domain.models.astronauts;
using allaboutspace_domain.models.common;
using allaboutspace_domain.models.launches;
using allaboutspace_domain.respository.interfaces;
using allaboutspace_repository.Constants;
using Flurl;
using Flurl.Http;
using Microsoft.Extensions.Configuration;


namespace allaboutspace_repository.Respositories
{
    public class LaunchesRepository : ILaunchesRepository
    {

        private readonly IConfiguration _config;
        private string url = string.Empty;
        public LaunchesRepository(IConfiguration configuration)
        {
            _config = configuration;
            url = $"{_config[EnvironmentConstants.TSD_BASEURL]}/{APIConstants.LaunchEndpoint}/";
        }
        public async Task<GenericPaginationResponse<LaunchList>> GetAllLaunchesByAsync(int limit, int offset)
        {
            var queryParams = new
            {
                mode = "list",
                limit = limit.ToString(),
                offset = offset.ToString(),
                order = "name",
                ordering = "name"
            };
            return await url.SetQueryParams(queryParams).GetJsonAsync<GenericPaginationResponse<LaunchList>>();
        }
    }
}
