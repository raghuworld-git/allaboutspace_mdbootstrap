﻿using allaboutspace_domain.models.common;
using System.Text;
using Type = allaboutspace_domain.models.common.Type;

namespace allaboutspace_api.Models
{
    public class AstronautsSimpleModel
    {
        public int id { get; set; }
        public string name { get; set; }
        public Status status { get; set; }
        public Type type { get; set; }
        public string agency { get; set; }
        public string time_in_space { get; set; }
        public string eva_time { get; set; }

        public string time_in_space_formatted
        {
            get
            {
                // P75DT23H53S
                var formattedString = new StringBuilder();

                string[] splitTwohalfsWithDate = time_in_space.Split('D');
                if (splitTwohalfsWithDate.Length > 0)
                {
                    formattedString.Append($"{splitTwohalfsWithDate[0].Replace("P", string.Empty)}D");
                }
                if (splitTwohalfsWithDate.Length == 2)
                {
                    var entireTimePart = splitTwohalfsWithDate[1].Replace("T", string.Empty);
                    var tempHourPart = entireTimePart.Split('H');

                    if (tempHourPart.Length > 0)
                    {
                        formattedString.Append($", {tempHourPart[0]}H");
                    }
                    if (tempHourPart.Length > 1)
                    {
                        formattedString.Append($", {tempHourPart[1]}");
                    }
                }


                return formattedString.ToString();
            }
        }
        public string eva_time_formatted
        {
            get
            {
                // P75DT23H53S
                var formattedString = new StringBuilder();

                string[] splitTwohalfsWithDate = eva_time.Split('D');
                if (splitTwohalfsWithDate.Length > 0)
                {
                    formattedString.Append($"{splitTwohalfsWithDate[0].Replace("P", string.Empty)}D");
                }
                if (splitTwohalfsWithDate.Length == 2)
                {
                    var entireTimePart = splitTwohalfsWithDate[1].Replace("T", string.Empty);
                    var tempHourPart = entireTimePart.Split('H');

                    if (tempHourPart.Length > 0)
                    {
                        formattedString.Append($", {tempHourPart[0]}H");
                    }
                    if (tempHourPart.Length > 1)
                    {
                        formattedString.Append($", {tempHourPart[1]}");
                    }
                }

                return formattedString.ToString();
            }
        }
        public bool in_space { get; set; }
        public string nationality { get; set; }
        public string? profile_image_thumbnail { get; set; }
    }
}
