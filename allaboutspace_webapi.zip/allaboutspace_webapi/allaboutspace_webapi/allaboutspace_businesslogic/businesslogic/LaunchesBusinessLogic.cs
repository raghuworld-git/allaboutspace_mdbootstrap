﻿

using allaboutspace_domain.business.interfaces;
using allaboutspace_domain.models.common;
using allaboutspace_domain.models.launches;
using allaboutspace_domain.respository.interfaces;

namespace allaboutspace_businesslogic.businesslogic
{
    public class LaunchesBusinessLogic : ILaunchesBusinessLogic
    {
        private readonly ILaunchesRepository _launchesRepository;

        public LaunchesBusinessLogic(ILaunchesRepository launchesRepository)
        {
            _launchesRepository = launchesRepository;
        }

        public async Task<GenericPaginationResponse<LaunchList>> GetAllPastLaunchesByAsync(int limit, int offset)
        {
            return await _launchesRepository.GetAllPastLaunchesByAsync(limit, offset);
        }

        public async Task<GenericPaginationResponse<LaunchList>> GetAllUpcomingLaunchesByAsync(int limit, int offset)
        {
            return await _launchesRepository.GetAllUpcomingLaunchesByAsync(limit, offset);
        }
    }
}
