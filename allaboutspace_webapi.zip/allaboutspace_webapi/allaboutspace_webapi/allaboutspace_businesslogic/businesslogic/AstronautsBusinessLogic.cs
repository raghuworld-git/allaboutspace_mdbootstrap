﻿using allaboutspace_domain.business.interfaces;
using allaboutspace_domain.models.astronauts;
using allaboutspace_domain.models.common;
using allaboutspace_domain.respository.interfaces;

namespace allaboutspace_businesslogic.businesslogic
{
    public class AstronautsBusinessLogic : IAstronautsBusinessLogic
    {
        private readonly IAstronautsRepository _astroRepository;

        public AstronautsBusinessLogic(IAstronautsRepository astronautsRepository)
        {
            _astroRepository = astronautsRepository;
        }
        public async Task<GenericPaginationResponse<AstronautSimple>> GetAllAstronautsByAsync(int limit, int offset)
        {
            return await _astroRepository.GetAllAstronautsByAsync(limit, offset);
        }

        public async Task<AstronautDetailed> GetAstronautByIdAsync(int id)
        {
            return await _astroRepository.GetAstronautByIdAsync(id);
        }
    }
}
