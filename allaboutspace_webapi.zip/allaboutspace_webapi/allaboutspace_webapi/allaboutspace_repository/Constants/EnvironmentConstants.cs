﻿namespace allaboutspace_repository.Constants
{
    public  static class EnvironmentConstants
    {
        public  const string TSD_BASEURL = "BASE_URLS:TSD_BaseURL";
    }
}
