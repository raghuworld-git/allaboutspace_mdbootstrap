﻿using allaboutspace_domain.models.common;
using allaboutspace_domain.models.launches;
using allaboutspace_domain.respository.interfaces;
using allaboutspace_repository.Constants;
using Flurl;
using Flurl.Http;
using Microsoft.Extensions.Configuration;


namespace allaboutspace_repository.Respositories
{
    public class LaunchesRepository : ILaunchesRepository
    {

        private readonly IConfiguration _config;
        private string url = string.Empty;
        public LaunchesRepository(IConfiguration configuration)
        {
            _config = configuration;
            url = $"{_config[EnvironmentConstants.TSD_BASEURL]}/{APIConstants.LaunchEndpoint}/";
        }

        public async Task<GenericPaginationResponse<LaunchList>> GetAllPastLaunchesByAsync(int limit, int offset)
        {
            var queryParams = new
            {
                mode = "list",
                limit = limit.ToString(),
                offset = offset.ToString()
            };
            return await $"{url}previous".SetQueryParams(queryParams).GetJsonAsync<GenericPaginationResponse<LaunchList>>();
        }

        public async Task<GenericPaginationResponse<LaunchList>> GetAllUpcomingLaunchesByAsync(int limit, int offset)
        {
            var queryParams = new
            {
                mode = "list",
                limit = limit.ToString(),
                offset = offset.ToString()
            };
            return await $"{url}upcoming".SetQueryParams(queryParams).GetJsonAsync<GenericPaginationResponse<LaunchList>>();
        }
    }
}
