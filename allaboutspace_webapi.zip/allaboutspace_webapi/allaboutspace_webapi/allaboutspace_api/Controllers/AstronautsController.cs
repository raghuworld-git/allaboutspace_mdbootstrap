﻿using allaboutspace_api.Models;
using allaboutspace_domain.business.interfaces;
using allaboutspace_domain.models.astronauts;
using allaboutspace_domain.models.common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace allaboutspace_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AstronautsController : ControllerBase
    {
        private readonly IAstronautsBusinessLogic _astroBL;        
        public AstronautsController(IAstronautsBusinessLogic astroBL)
        {
            _astroBL = astroBL;           
        }

        [HttpGet]
        [Route("[action]")]
        public async Task<ActionResult<GenericPaginationResponse<AstronautSimple>>> GetAllAstronauts(int limit = 8, int offset = 10)
        {            
            var result = await _astroBL.GetAllAstronautsByAsync(limit, offset);
            if (result is not null)
            {
                if (result.count >= 1)
                {
                    return Ok(result);
                }
            }

            return NotFound();

        }

        [HttpGet]
        [Route("[action]/{id:int}")]
        public async Task<ActionResult<AstronautDetailed>> GetAstronautById(int id)
        {
            var result = await _astroBL.GetAstronautByIdAsync(id);
            if (result is not null)
            {
                return Ok(result);
            }
            return NotFound();
        }
    }
}
