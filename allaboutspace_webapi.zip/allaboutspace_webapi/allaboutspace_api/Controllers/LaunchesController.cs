﻿using allaboutspace_domain.business.interfaces;
using allaboutspace_domain.models.astronauts;
using allaboutspace_domain.models.common;
using allaboutspace_domain.models.launches;
using Microsoft.AspNetCore.Mvc;

namespace allaboutspace_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LaunchesController : ControllerBase
    {
        private readonly ILaunchesBusinessLogic _launchesBL;

        public LaunchesController(ILaunchesBusinessLogic launchesBL)
        {
            _launchesBL = launchesBL;
        }
        [HttpGet]
        [Route("[action]")]
        public async Task<ActionResult<GenericPaginationResponse<LaunchList>>> GetAllLaunches(int limit = 8, int offset = 10)
        {
            var result = await _launchesBL.GetAllLaunchesByAsync(limit, offset);
            if (result is not null)
            {
                if (result.count >= 1)
                {
                    return Ok(result);
                }
            }

            return NotFound();

        }
    }
}
