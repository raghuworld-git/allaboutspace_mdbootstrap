﻿namespace allaboutspace_domain.models.common
{
    public class Type
    {
        public int id { get; set; }
        public string name { get; set; }

    }
}
