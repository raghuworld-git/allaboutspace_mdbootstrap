﻿using allaboutspace_domain.models.common;


namespace allaboutspace_domain.models.launches
{
    public class Mission
    {
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string type { get; set; }
        public Status orbit { get; set; }
    }
}
