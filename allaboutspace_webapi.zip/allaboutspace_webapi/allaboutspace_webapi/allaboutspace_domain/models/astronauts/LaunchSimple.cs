﻿using allaboutspace_domain.models.common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Type = allaboutspace_domain.models.common.Type;

namespace allaboutspace_domain.models.astronauts
{
    public class LaunchSimple
    {
        public string id { get; set; }
        public string slug { get; set; }
        public Status status { get; set; }
        public string image { get; set; }

    }
}
