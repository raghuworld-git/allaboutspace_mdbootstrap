﻿namespace allaboutspace_domain.models.agency
{
    public class Agency
    {
        public int id { get; set; }
        public string name { get; set; }

        public string? type { get; set; }
    }
}
