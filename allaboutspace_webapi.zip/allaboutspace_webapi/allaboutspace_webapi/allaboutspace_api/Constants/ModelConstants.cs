﻿namespace allaboutspace_api.Constants
{
    public static class ModelConstants
    {
        public const string RegexPatternForTIS = @"^P([0-9]+D)?T([0-9]+H[0-9]+S)?$";
        public const string RegexPatternForEVA = @"^P([0-9]+D)?T([0-9]+H[0-9]+S)?$";
    }
}
